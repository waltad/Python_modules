from .c2 import *
from .c3.result_info import inform_about_the_result
