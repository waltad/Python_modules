def retrieve_number_from_user():
    number = int(input("Podaj liczbe jaka obstawiasz: "))
    return number
