def inform_about_the_result(times):
    print(f"Twoja liczba zostala wylosowana po {times} razie(-ach).")

def inform_about_the_result():
    raise Exception