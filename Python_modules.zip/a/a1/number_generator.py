"""
    Generator liczb naturalnych.
    Zaślepka.

    Autor: jakiś kawalarz
"""


def generate_number_between(min, max):
    print("Udaje, ze losuje, zwracam zawsze to samo")
    return 0


def generate_until_drawn(number, min, max):
    print("Udaje, ze losuje w petli, a zwracam zawsze to samo")
    return -1
