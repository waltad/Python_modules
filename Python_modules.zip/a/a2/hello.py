def hello():
    print("Witaj na loterii lotto!")